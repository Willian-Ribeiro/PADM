package br.edu.ufabc.padm.flickrgallery2;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class FlickrPhotoAdapter extends RecyclerView.Adapter<FlickrPhotoAdapter.FlickrPhotoViewHolder> {

    private static final String LOGTAG = FlickrPhotoAdapter.class.getSimpleName();

    MutableLiveData<List<FlickrPhoto>> photos;

    public FlickrPhotoAdapter() {
        this.photos = new MutableLiveData<>();
    }

    public class FlickrPhotoViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        FlickrThumbnailDownloaderTask task;
        FlickrPhoto photo;


        public FlickrPhotoViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.flickr_thumbnail);
        }

        public boolean taskIsRunning() {
            return task != null &&
                    (task.getStatus() == AsyncTask.Status.PENDING ||
                            task.getStatus() == AsyncTask.Status.RUNNING);
        }
    }

    @NonNull
    @Override
    public FlickrPhotoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new FlickrPhotoViewHolder(
                LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.gallery_item, parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull FlickrPhotoViewHolder holder, int position) {
        if (FlickrGalleryApp.getContext().isNetworkConnected()) {
            if (holder.taskIsRunning()) { // cancel a previously running download task
                holder.task.cancel(true);
                Log.d(LOGTAG, "Download canceled for photo " + holder.photo.getId());
            }
            holder.imageView.setImageBitmap(null); // make it blank
            holder.photo = photos.getValue().get(position);
            holder.task = new FlickrThumbnailDownloaderTask(holder.imageView);
            holder.task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, holder.photo);
        } else {
            Log.e(LOGTAG, "No network available, impossible to download.");
        }
    }

    @Override
    public int getItemCount() {
        return photos.getValue().size();
    }

    /**
     * AsyncTask to download the thumbnail of a single image
     */
    private class FlickrThumbnailDownloaderTask extends AsyncTask<FlickrPhoto, Void, Bitmap> {
        private WeakReference<ImageView> imageViewWK;

        public FlickrThumbnailDownloaderTask(ImageView imageView) {
            this.imageViewWK = new WeakReference<>(imageView);
        }

        /**
         * Download the thumbnail in a dedicated thread
         * @param params the thumbnail url
         * @return a bitmap with the thumbnail
         */
        @Override
        protected Bitmap doInBackground(FlickrPhoto... params) {
            URL url;
            HttpURLConnection conn;
            Bitmap bitmap = null;
            int responseCode;
            FlickrPhoto photo;

            if (params.length > 0) {
                photo = params[0];
                try {
                    url = new URL(photo.getThumbURL());
                    conn = (HttpURLConnection )url.openConnection();
                    conn.connect();
                    responseCode = conn.getResponseCode();
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        Log.d(LOGTAG, "Downloading thumbnail id: " + photo.getId());
                        bitmap = BitmapFactory.decodeStream(conn.getInputStream());
                    } else
                        Log.e(LOGTAG, "Failed to download thumbnail. HTTP code: " + responseCode);
                } catch (MalformedURLException e) {
                    Log.e(LOGTAG, "Malformed thumbnail URL", e);
                } catch (IOException e) {
                    Log.e(LOGTAG, "Failed to open thumbnail URL", e);
                }
            }

            return bitmap;
        }

        /**
         * Update the view (passed to the constructor) with the  downloaded bitmap
         * @param bitmap the downloaded bitmap
         */
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                if (imageViewWK != null)
                    imageViewWK.get().setImageBitmap(bitmap);
            } else {
                Log.e(LOGTAG, "Failed to download thumbnail");
            }
        }

    }
}
