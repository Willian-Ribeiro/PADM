package br.edu.ufabc.padm.flickrgallery2;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A JSON serializer for the flickr web service. The serializer is stateful, therefore
 * it should be used for a single JSON document
 */
public class FlickrJSONSerializer {

    /**
     * A contract for the Flickr JSON format
     */
    private static final class FlickrJSONContract {
        public static final String PHOTO_OBJECT = "photos";
        public static final String PHOTO_ARRAY = "photo";
        public static final String PHOTO_ID = "id";
        public static final String PHOTO_THUMB_URL = "url_s";
        public static final String PHOTO_TITLE = "title";
        public static final String STATUS = "stat";
        public static final String STATUS_FAILED = "failed";
        public static final String STATUS_OK = "ok";
    }

    private final String LOGTAG = FlickrJSONSerializer.class.getSimpleName();

    private JSONObject root;

    /**
     * Builds the initializer with a json string
     * @param jsonStr
     * @throws JSONException
     */
    public FlickrJSONSerializer(String jsonStr) throws JSONException {
        root = new JSONObject(jsonStr);
    }

    /**
     * Check if status of the action response
     * @return
     * @throws JSONException
     */
    public boolean isStatusOk() throws JSONException {
        String statusStr = root.getString(FlickrJSONContract.STATUS);
        boolean isOk = false;

        if (statusStr != null && statusStr.equals(FlickrJSONContract.STATUS_OK))
            isOk = true;

        return isOk;
    }

    /**
     * Deserialize a list of recent photos
     * @return a list of FlickrPhoto objects
     * @throws JSONException
     */
    public ArrayList<FlickrPhoto> deserializeRecentPhotos() throws JSONException {
        ArrayList<FlickrPhoto> photos = new ArrayList<>();

        JSONArray photosArray;

        if (root != null) {
            photosArray = root.getJSONObject(FlickrJSONContract.PHOTO_OBJECT)
                    .getJSONArray(FlickrJSONContract.PHOTO_ARRAY);
            for (int i = 0; i < photosArray.length(); i++) {
                JSONObject photoObj = (JSONObject) photosArray.get(i);
                FlickrPhoto photo = new FlickrPhoto();

                photo.setId(Long.parseLong(photoObj.getString(FlickrJSONContract.PHOTO_ID)));
                photo.setTitle(photoObj.getString(FlickrJSONContract.PHOTO_TITLE));
                if (photoObj.has(FlickrJSONContract.PHOTO_THUMB_URL))
                    photo.setThumbURL(photoObj.getString(FlickrJSONContract.PHOTO_THUMB_URL));
                photos.add(photo);
            }
        }

        return photos;
    }
}
