package br.edu.ufabc.padm.flickrgallery2;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class FlickrGalleryViewModel extends ViewModel {
    FlickrPhotoAdapter flickrPhotoAdapter;
    MutableLiveData<String> statusMessage;
    private FlickrFetcherTask flickrFetcherTask;

    private class FlickrFetcherTask extends AsyncTask<Void, Void, ArrayList<FlickrPhoto>> {

        @Override
        protected ArrayList<FlickrPhoto> doInBackground(Void... voids) {
            return FlickrFetcher.fetchRecentPhotos(statusMessage);
        }

        @Override
        protected void onPostExecute(ArrayList<FlickrPhoto> photos) {
            flickrPhotoAdapter.photos.setValue(photos);
        }
    }

    public FlickrGalleryViewModel() {
        flickrPhotoAdapter = new FlickrPhotoAdapter();
        statusMessage = new MutableLiveData<>();
    }

    public void loadPhotos() {
        if (FlickrGalleryApp.isNetworkConnected()) {
            flickrFetcherTask = new FlickrFetcherTask();
            flickrFetcherTask.execute();
        } else
            statusMessage.setValue(FlickrGalleryApp.getContext().getString(R.string.no_network));

    }

    @Override
    protected void onCleared() {
        super.onCleared();

        if (flickrFetcherTask != null &&
                flickrFetcherTask.getStatus() == AsyncTask.Status.PENDING ||
                flickrFetcherTask.getStatus() == AsyncTask.Status.RUNNING)
            flickrFetcherTask.cancel(true);
    }

    /**
     * Utility class to download and parse JSON files
     * from the web service
     */
    private static class FlickrFetcher {

        /**
         * A contract for the web service API
         */
        private final class FlickrContract {
            public static final String FLICKR_REST_ENDPOINT = "https://api.flickr.com/services/rest/";
            public static final String API_KEY_K = "api_key";
            private static final String API_KEY_V = "ad09fc474fe44fd5418951b62b121cbd"; // change to your own key
            public static final String FORMAT_K = "format";
            public static final String FORMAT_V = "json";
            public static final String EXTRAS_K = "extras";
            public  static final String EXTRAS_V = "url_s";
            public static final String METHOD_K = "method";
            public static final String GET_RECENT_METHOD = "flickr.photos.getRecent";
            public static final String NO_JSON_CALLBACK_K = "nojsoncallback";
            public static final String NO_JSON_CALLBACK_V = "1";
        }

        private static final int BUFFER_SIZE = 1024;
        private static final String LOGTAG = FlickrFetcher.class.getSimpleName();

        private FlickrFetcher() {}

        /**
         * Fetch a list of recent photos from Flickr
         * @return
         */
        public static ArrayList<FlickrPhoto> fetchRecentPhotos(MutableLiveData<String> statusMessage) {
            ArrayList<FlickrPhoto> photos = new ArrayList<>();
            URL url;
            String urlStr = null;
            HttpURLConnection conn = null;
            int responseCode;
            String responseContent;
            FlickrJSONSerializer flickrJSONSerializer;

            try {
                urlStr = Uri.parse(FlickrContract.FLICKR_REST_ENDPOINT).buildUpon()
                        .appendQueryParameter(FlickrContract.METHOD_K, FlickrContract.GET_RECENT_METHOD)
                        .appendQueryParameter(FlickrContract.API_KEY_K, FlickrContract.API_KEY_V)
                        .appendQueryParameter(FlickrContract.FORMAT_K, FlickrContract.FORMAT_V)
                        .appendQueryParameter(FlickrContract.EXTRAS_K, FlickrContract.EXTRAS_V)
                        .appendQueryParameter(FlickrContract.NO_JSON_CALLBACK_K, FlickrContract.NO_JSON_CALLBACK_V)
                        .build().toString();
                Log.d(LOGTAG, urlStr);
                url = new URL(urlStr);
                conn = (HttpURLConnection )url.openConnection();
                conn.connect();
                responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                    InputStream inputStream = conn.getInputStream();
                    int len;
                    byte[] buffer = new byte[BUFFER_SIZE];

                    while ((len = inputStream.read(buffer)) > 0)
                        outputStream.write(buffer, 0, len);
                    outputStream.flush();
                    outputStream.close();
                    inputStream.close();

                    responseContent = new String(outputStream.toByteArray());
                    try {
                        flickrJSONSerializer = new FlickrJSONSerializer(responseContent);
                        if (flickrJSONSerializer.isStatusOk())
                            photos.addAll(flickrJSONSerializer.deserializeRecentPhotos());
                        else {

                        }
                    } catch (JSONException e) {
                        Log.e(LOGTAG, "Failed to parse JSON response document", e);
                        statusMessage.postValue(FlickrGalleryApp.getContext()
                                .getString(R.string.parsing_failed));
                    }
                    Log.d(LOGTAG, "Total photos retrieved: " + photos.size());
                } else {
                    Log.e(LOGTAG, "Wrong response code while getting Flickr doc: " + responseCode);
                    statusMessage.postValue(FlickrGalleryApp.getContext()
                            .getString(R.string.connection_failed));
                }
            } catch (MalformedURLException e) {
                Log.e(LOGTAG, "Malformed URL: " + urlStr, e);
                statusMessage.postValue(FlickrGalleryApp.getContext()
                        .getString(R.string.connection_failed));
            } catch (IOException e) {
                Log.e(LOGTAG, "Failed to connect to URL", e);
                statusMessage.postValue(FlickrGalleryApp.getContext()
                        .getString(R.string.connection_failed));
            } finally {
                conn.disconnect();
            }

            return photos;
        }

    }
}
