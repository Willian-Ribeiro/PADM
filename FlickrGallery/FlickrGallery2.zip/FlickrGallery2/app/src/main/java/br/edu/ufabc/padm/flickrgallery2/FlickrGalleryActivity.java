package br.edu.ufabc.padm.flickrgallery2;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;


public class FlickrGalleryActivity extends AppCompatActivity {

    private RecyclerView recyclerGridView;
    private FlickrGalleryViewModel viewModel;

    private static final String LOGTAG = FlickrGalleryActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery_flickr);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.alternate_main_title));

        viewModel = ViewModelProviders.of(this).get(FlickrGalleryViewModel.class);
        // delay adapter set up until first photos array is ready
        viewModel.flickrPhotoAdapter.photos.observe(this, new Observer<List<FlickrPhoto>>() {
            @Override
            public void onChanged(List<FlickrPhoto> flickrPhotos) {
                recyclerGridView.setAdapter(viewModel.flickrPhotoAdapter);
                viewModel.flickrPhotoAdapter.photos.removeObserver(this);
            }
        });
        viewModel.flickrPhotoAdapter.photos.observe(this, new Observer<List<FlickrPhoto>>() {
            @Override
            public void onChanged(List<FlickrPhoto> flickrPhotos) {
                viewModel.flickrPhotoAdapter.notifyDataSetChanged();
            }
        });
        viewModel.statusMessage.observe(this, new Observer<String>() {
            @Override
            public void onChanged(String message) {
                Snackbar.make(
                        findViewById(R.id.layout_main),
                        message,
                        Snackbar.LENGTH_LONG).show();
            }
        });
        recyclerGridView = findViewById(R.id.photo_grid);
        recyclerGridView.setHasFixedSize(true);
        recyclerGridView.setLayoutManager(new GridLayoutManager(this, 2));

        viewModel.loadPhotos();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
