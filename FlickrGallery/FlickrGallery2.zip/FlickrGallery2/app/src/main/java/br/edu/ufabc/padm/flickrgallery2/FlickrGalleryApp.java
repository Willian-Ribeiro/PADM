package br.edu.ufabc.padm.flickrgallery2;

import android.app.Application;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;

public class FlickrGalleryApp extends Application {

    private static FlickrGalleryApp mContext;

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this;
    }


    public static FlickrGalleryApp getContext() {
        return mContext;
    }

    /**
     * Check if the external storage has write permission for this app. Should be called at
     * every attempt to write to external storage
     *
     * @return true if it is writable, false otherwise
     */
    public static boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }

    /**
     * Check if external storage has read permission for the app. Should be called at
     * every attempt to read the external storage
     * @return true in case it is readable, false otherwise
     */
    public static boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }
        return false;
    }



    /**
     * Check if there is a working network connection in the device
     *
     * @return true if there is a connection, false otherwise
     */
    public static boolean isNetworkConnected() {
        boolean status = false;

        ConnectivityManager connectivityManager =
                (ConnectivityManager ) FlickrGalleryApp.getContext()
                        .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected())
            status = true;

        return status;
    }

}