package br.edu.ufabc.padm.flickrgallery2;


public class FlickrPhoto {
    private Long id;
    private String title;
    private String thumbURL;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getThumbURL() {
        return thumbURL;
    }

    public void setThumbURL(String thumbURL) {
        this.thumbURL = thumbURL;
    }

    public boolean hasThumbURL() {
        return thumbURL != null;
    }
}
